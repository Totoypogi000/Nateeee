<br />
<div align="center">
    <img src="src/img/icon.png">
  </a>
</div>

<p align="center">
    <a href="https://discord.gg/CxG3f7S">
        <img src="https://img.shields.io/discord/675323046680330261.svg?label=Discord&logo=discord" alt="Discord"/>
    </a>
     <a href="https://shoppy.gg/product/NJzfO9I">
        <img src="https://img.shields.io/badge/Buy%20here-Shoppy-green">
    </a>
</p>



<h3 align="center">Non-injectable</h3>
<p align="center">Working externally with Computer Vision and AI </p>

<p align="center">Your account will NEVER be banned. </p>
<p align="center"> Created to help and make Ball Pool more fun <b><a href="https://www.youtube.com/watch?v=iAhjjpUNwUc">Youtube Video</a></b></p>

<p align="center">Link to buy: <b><a href="https://shoppy.gg/product/NJzfO9I">Shoppy</a></p>

<br>

<h1 align="center">Guide Line</h1>

<p align="center">
    <img style="width: 47%;" src="https://cdn.discordapp.com/attachments/396904623668985865/810546822526795796/gifModo2.gif"/>
    <img src="https://cdn.discordapp.com/attachments/675323146743578650/941501241001922590/automode1.gif"/>
</p>



## Installation

- **[YouTube Video Tutorial](https://youtu.be/31aOwEu9AgU)**

**1.** Install **[Node.JS!](https://nodejs.org/en/download/)**<br>
**2.** Download and extract the **[repository](https://github.com/Felipefury/Guide-Line/archive/master.zip)** to your pc.<br>
**3.** Open **install.bat** (it'll auto close).<br>
**4.** Open **run.bat**<br>
**5.** Create an account and login.<br>
**6.** Now you can use the *free* version, if you want all functions buy the paid version: **[Shoppy!](https://shoppy.gg/product/NJzfO9I)**



## Why our system is safe and you will not be punished?

**Q:** How does it work?

**A:** We do not do any type of injection or changes in the game's source code, we create an overlay on your screen.

![How work](https://cdn.discordapp.com/attachments/396904623668985865/810546814481727558/howwork.gif)



## Our Feedback

<p >
    <a href="https://shoppy.gg/@FelipeGM/feedback">
        <img style="width: 85%" src="https://cdn.discordapp.com/attachments/675323146743578650/921122674439233576/all2.png"/>
    </a>
</p>



## Compatibility
* **PC**
    * - [x] **Microsoft Windows (7,8,8.1,10,11).** Manual Mode: ✅, Auto Mode: ✅
    * - [x] **Linux.** Manual Mode: ✅, Auto Mode: ?
    * - [x] **macOS.** Manual Mode: ✅, Auto Mode: 70%
